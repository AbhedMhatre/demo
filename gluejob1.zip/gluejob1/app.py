#!/usr/bin/env python3

from aws_cdk import core

from gluejob1.gluejob1_stack import Gluejob1Stack
from gluejob1.gluecrawler import GluedemoStack
from gluejob1.gluedatabase import GluedatabaseStack
from gluejob1.s3assect import s3AssectStack
from gluejob1.s3bucket import HelloCdkStack




app = core.App()
Gluejob1Stack(app, "gluejob1")
GluedemoStack(app, "gluecrawler")
GluedatabaseStack(app, "gluedatabae")
s3AssectStack(app,"s3assect")
HelloCdkStack(app,"s3bucket")
app.synth()
