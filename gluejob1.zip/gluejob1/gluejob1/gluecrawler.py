from aws_cdk import (aws_s3 as s3,aws_glue as glue,core)

class GluedemoStack(core.Stack):

    def __init__(self, scope: core.Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # The code that defines your stack goes here
        glue_crawler = glue.CfnCrawler(self, 'glue-crawler-id',description="Glue Crawler for my-data-science-s3",
        name='nickcrawler',database_name='nickdemo',schedule=None,role='arn:aws:iam::147279300887:role/successnick',
        targets={"s3Targets": [{"path": "s3://nikhil/file"}]})
